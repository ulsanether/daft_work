                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1671517
Mostly Printed CNC 525 MPCNC "J-25.4mm = 1" OD" by Allted is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Changelog
3/19/18 - New foot design.
5/9/17 - New XYZ Part to allow for T8 Leadscrew driven Z axis.
8/8/16 - Fixed a small dimensional error with the corner assemblies. -Thanks Martin S
7/13/16 - New Roller Assemblies. No more motor mount flex, less hardware needed. More, mostly printed!
5/25/16 - New Center and Z Axis assemblies, More rigid!, easier to square, universal tool mount.
4/24/16 - New Corner assembly, easier to square, shorter print time, more rigid.

Mostly Printed CNC / MultiTool
These parts are for 25.4mm = 1" OD conduit.

More info here https://www.vicious1.com/, and http://www.thingiverse.com/thing:724999

Parts list, https://www.vicious1.com/blog/parts/