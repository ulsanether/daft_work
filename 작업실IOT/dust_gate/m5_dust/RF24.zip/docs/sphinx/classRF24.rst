RF24 class
~~~~~~~~~~

.. cpp:class:: RF24

    .. doxygenfunction:: RF24::RF24 (uint16_t,uint16_t,uint32_t)
    .. doxygenfunction:: RF24::RF24 (uint32_t _spi_speed=RF24_SPI_SPEED)

Basic API
============

.. doxygenfunction:: RF24::begin (void)
.. doxygenfunction:: RF24::begin (_SPI *spiBus)
.. doxygenfunction:: RF24::begin (_SPI *spiBus, uint16_t _cepin, uint16_t _cspin)
.. doxygenfunction:: RF24::begin (uint16_t _cepin, uint16_t _cspin)
.. doxygenfunction:: RF24::isChipConnected
.. doxygenfunction:: RF24::startListening
.. doxygenfunction:: RF24::stopListening
.. doxygenfunction:: RF24::available (void)
.. doxygenfunction:: RF24::read
.. doxygenfunction:: RF24::write (const void *buf, uint8_t len)
.. doxygenfunction:: RF24::openWritingPipe (const uint8_t *address)
.. doxygenfunction:: RF24::openWritingPipe (uint64_t address)
.. doxygenfunction:: RF24::openReadingPipe (uint8_t number, const uint8_t *address)
.. doxygenfunction:: RF24::openReadingPipe (uint8_t number, uint64_t address)

Advanced API
============

.. doxygenvariable:: RF24::failureDetected
.. doxygenfunction:: RF24::printDetails
.. doxygenfunction:: RF24::printPrettyDetails
.. doxygenfunction:: RF24::available (uint8_t *pipe_num)
.. doxygenfunction:: RF24::rxFifoFull
.. doxygenfunction:: RF24::powerDown
.. doxygenfunction:: RF24::powerUp
.. doxygenfunction:: RF24::write (const void *buf, uint8_t len, const bool multicast)
.. doxygenfunction:: RF24::writeFast (const void *buf, uint8_t len)
.. doxygenfunction:: RF24::writeFast (const void *buf, uint8_t len, const bool multicast)
.. doxygenfunction:: RF24::writeBlocking
.. doxygenfunction:: RF24::txStandBy()
.. doxygenfunction:: RF24::txStandBy (uint32_t timeout, bool startTx=0)
.. doxygenfunction:: RF24::writeAckPayload
.. doxygenfunction:: RF24::isAckPayloadAvailable
.. doxygenfunction:: RF24::whatHappened
.. doxygenfunction:: RF24::startFastWrite
.. doxygenfunction:: RF24::startWrite
.. doxygenfunction:: RF24::reUseTX
.. doxygenfunction:: RF24::flush_tx
.. doxygenfunction:: RF24::flush_rx
.. doxygenfunction:: RF24::testCarrier
.. doxygenfunction:: RF24::testRPD
.. doxygenfunction:: RF24::isValid
.. doxygenfunction:: RF24::closeReadingPipe

Configuration API
==================

.. doxygenvariable:: RF24::txDelay
.. doxygenvariable:: RF24::csDelay
.. doxygenfunction:: RF24::setAddressWidth
.. doxygenfunction:: RF24::setRetries
.. doxygenfunction:: RF24::setChannel
.. doxygenfunction:: RF24::getChannel
.. doxygenfunction:: RF24::setPayloadSize
.. doxygenfunction:: RF24::getPayloadSize
.. doxygenfunction:: RF24::getDynamicPayloadSize
.. doxygenfunction:: RF24::enableAckPayload
.. doxygenfunction:: RF24::disableAckPayload
.. doxygenfunction:: RF24::enableDynamicPayloads
.. doxygenfunction:: RF24::disableDynamicPayloads
.. doxygenfunction:: RF24::enableDynamicAck
.. doxygenfunction:: RF24::isPVariant
.. doxygenfunction:: RF24::setAutoAck (bool enable)
.. doxygenfunction:: RF24::setAutoAck (uint8_t pipe, bool enable)
.. doxygenfunction:: RF24::setPALevel
.. doxygenfunction:: RF24::getPALevel
.. doxygenfunction:: RF24::getARC
.. doxygenfunction:: RF24::setDataRate
.. doxygenfunction:: RF24::getDataRate
.. doxygenfunction:: RF24::setCRCLength
.. doxygenfunction:: RF24::getCRCLength
.. doxygenfunction:: RF24::disableCRC
.. doxygenfunction:: RF24::maskIRQ
.. doxygenfunction:: RF24::startConstCarrier
.. doxygenfunction:: RF24::stopConstCarrier
.. doxygenfunction:: RF24::toggleAllPipes
.. doxygenfunction:: RF24::setRadiation

Protected API
==============

These are the members and functions made available to derivatives that inherit from the RF24 class.

.. doxygenfunction:: RF24::beginTransaction
.. doxygenfunction:: RF24::endTransaction
.. doxygenfunction:: RF24::read_register (uint8_t reg, uint8_t *buf, uint8_t len)
.. doxygenfunction:: RF24::read_register (uint8_t reg)
.. doxygenvariable:: RF24::ack_payloads_enabled
.. doxygenvariable:: RF24::addr_width
.. doxygenvariable:: RF24::dynamic_payloads_enabled
