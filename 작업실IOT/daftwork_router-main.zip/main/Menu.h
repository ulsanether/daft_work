
const char *menu_setup[] = {"","",""}; // id=1
